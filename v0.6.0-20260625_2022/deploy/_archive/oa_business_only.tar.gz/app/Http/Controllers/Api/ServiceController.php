<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{ServiceOrder, ServiceOrderLog, ServiceOrderPart, MaintenanceContract, Customer};
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ServiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = ServiceOrder::with(['customer', 'assignedUser', 'device']);
        if ($request->filled('keyword')) $query->where('order_no', 'like', "%{$request->keyword}%")->orWhere('fault_description', 'like', "%{$request->keyword}%");
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('urgency')) $query->where('urgency', $request->urgency);
        if ($request->filled('customer_id')) $query->where('customer_id', $request->customer_id);

        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }

    public function show(ServiceOrder $serviceOrder): JsonResponse
    {
        $serviceOrder->load(['customer', 'project', 'device', 'assignedUser', 'creator', 'logs.user', 'parts']);
        return response()->json(['code' => 0, 'data' => $serviceOrder]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'customer_id' => 'required|exists:customers,id', 'project_id' => 'nullable|exists:projects,id',
            'customer_device_id' => 'nullable|exists:customer_devices,id',
            'fault_description' => 'required|string', 'fault_photos' => 'nullable|array',
            'urgency' => 'required|string', 'service_type' => 'required|string', 'sla_hours' => 'nullable|integer',
        ]);
        $data['created_by'] = Auth::id();
        $data['status'] = 'pending';
        $order = ServiceOrder::create($data);
        return response()->json(['code' => 0, 'message' => '工单创建成功', 'data' => $order->load('customer')]);
    }

    public function assign(Request $request, ServiceOrder $serviceOrder): JsonResponse
    {
        $request->validate(['assigned_to' => 'required|exists:users,id']);
        $serviceOrder->update(['assigned_to' => $request->assigned_to, 'assigned_at' => now(), 'status' => 'assigned']);
        ServiceOrderLog::create(['service_order_id' => $serviceOrder->id, 'user_id' => Auth::id(), 'action' => 'assigned', 'content' => "工单已派给 {$serviceOrder->assignedUser->name}"]);
        return response()->json(['code' => 0, 'message' => '派单成功']);
    }

    public function startRepair(Request $request, ServiceOrder $serviceOrder): JsonResponse
    {
        $serviceOrder->update(['status' => 'in_progress', 'started_at' => now()]);
        ServiceOrderLog::create(['service_order_id' => $serviceOrder->id, 'user_id' => Auth::id(), 'action' => 'started', 'content' => '开始维修']);
        return response()->json(['code' => 0, 'message' => '维修已开始']);
    }

    public function completeRepair(Request $request, ServiceOrder $serviceOrder): JsonResponse
    {
        $data = $request->validate(['repair_content' => 'required|string', 'photos' => 'nullable|array', 'parts' => 'nullable|array']);
        $serviceOrder->update(['status' => 'completed', 'completed_at' => now()]);
        ServiceOrderLog::create(['service_order_id' => $serviceOrder->id, 'user_id' => Auth::id(), 'action' => 'completed', 'content' => $data['repair_content'], 'photos' => $data['photos'] ?? []]);

        if (!empty($data['parts'])) {
            foreach ($data['parts'] as $part) {
                ServiceOrderPart::create(['service_order_id' => $serviceOrder->id, 'part_name' => $part['name'], 'quantity' => $part['quantity'], 'unit_cost' => $part['unit_cost'] ?? 0, 'total_cost' => ($part['quantity'] ?? 1) * ($part['unit_cost'] ?? 0)]);
            }
        }

        return response()->json(['code' => 0, 'message' => '维修完成']);
    }

    public function confirmByCustomer(Request $request, ServiceOrder $serviceOrder): JsonResponse
    {
        $data = $request->validate(['rating' => 'nullable|integer|min:1|max:5', 'review' => 'nullable|string']);
        $serviceOrder->update(['status' => 'confirmed', 'confirmed_at' => now(), 'rating' => $data['rating'] ?? null, 'review' => $data['review'] ?? null]);
        return response()->json(['code' => 0, 'message' => '已确认完工']);
    }

    public function stats(Request $request): JsonResponse
    {
        $monthStart = now()->startOfMonth();
        $totalOrders = ServiceOrder::where('created_at', '>=', $monthStart)->count();
        $completedOrders = ServiceOrder::where('created_at', '>=', $monthStart)->where('status', 'confirmed')->count();
        $slaRate = $totalOrders > 0 ? round($completedOrders / $totalOrders * 100, 1) : 100;
        $avgResponse = ServiceOrder::whereNotNull('assigned_at')->where('created_at', '>=', $monthStart)->selectRaw('AVG(TIMESTAMPDIFF(MINUTE, created_at, assigned_at)) as avg_minutes')->value('avg_minutes') ?? 0;
        $avgRating = ServiceOrder::whereNotNull('rating')->where('created_at', '>=', $monthStart)->avg('rating') ?? 0;

        return response()->json(['code' => 0, 'data' => compact('totalOrders', 'completedOrders', 'slaRate', 'avgResponse', 'avgRating')]);
    }

    public function maintenanceContracts(Request $request): JsonResponse
    {
        $query = MaintenanceContract::with('customer');
        if ($request->filled('status')) $query->where('status', $request->status);
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }
}
