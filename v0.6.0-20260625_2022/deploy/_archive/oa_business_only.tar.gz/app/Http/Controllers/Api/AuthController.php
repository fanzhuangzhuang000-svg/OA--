<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Project;
use App\Models\ServiceOrder;
use App\Models\AttendanceRecord;
use App\Models\ExpenseClaim;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $user = User::where('username', $request->username)->first();

        if (! $user || ! \Hash::check($request->password, $user->password)) {
            return response()->json(['code' => 401, 'message' => '用户名或密码错误'], 401);
        }

        if ($user->status !== 'active') {
            return response()->json(['code' => 403, 'message' => '账号已被禁用'], 403);
        }

        $token = $user->createToken('oa-token')->plainTextToken;
        $user->update(['last_login_at' => now(), 'last_login_ip' => $request->ip()]);

        // 记录登录日志
        DB::table('system_logs')->insert([
            'user_id' => $user->id, 'type' => 'login', 'module' => 'auth',
            'action' => 'login', 'description' => '用户登录',
            'ip' => $request->ip(), 'user_agent' => $request->userAgent(),
            'created_at' => now(), 'updated_at' => now(),
        ]);

        return response()->json([
            'code' => 0, 'message' => '登录成功',
            'data' => [
                'token' => $token,
                'user' => [
                    'id' => $user->id, 'name' => $user->name, 'username' => $user->username,
                    'avatar' => $user->avatar, 'phone' => $user->phone, 'email' => $user->email,
                    'department' => $user->department?->name,
                    'position' => $user->position?->name,
                ],
                'permissions' => $user->getAllPermissions()->pluck('name'),
                'roles' => $user->getRoleNames(),
            ],
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        DB::table('system_logs')->insert([
            'user_id' => Auth::id(), 'type' => 'logout', 'module' => 'auth',
            'action' => 'logout', 'description' => '用户退出',
            'ip' => $request->ip(), 'user_agent' => $request->userAgent(),
            'created_at' => now(), 'updated_at' => now(),
        ]);

        $request->user()->currentAccessToken()->delete();
        return response()->json(['code' => 0, 'message' => '退出成功']);
    }

    public function userInfo(Request $request): JsonResponse
    {
        $user = $request->user()->load(['department', 'position', 'profile', 'roles']);
        return response()->json([
            'code' => 0,
            'data' => [
                'user' => $user,
                'permissions' => $user->getAllPermissions()->pluck('name'),
                'roles' => $user->getRoleNames(),
            ],
        ]);
    }
}
