<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{Customer, CustomerContact, FollowUpRecord, CustomerDevice, User, Department, Position, EmployeeProfile, SkillTag, Certificate, ExpenseClaim, ExpenseItem, Vehicle, VehicleInsurance, VehicleMaintenanceRecord, VehicleUsageRequest, Warehouse, InventoryItem, StockRecord, DeviceSerialNumber, Receivable, Payable, DiskFolder, DiskFile, KnowledgeCategory, KnowledgeArticle};
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = User::with(['department', 'position', 'profile'])->where('status', 'active');
        if ($request->filled('keyword')) $query->where('name', 'like', "%{$request->keyword}%")->orWhere('username', 'like', "%{$request->keyword}%");
        if ($request->filled('department_id')) $query->where('department_id', $request->department_id);
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate(['name' => 'required|string', 'username' => 'required|string|unique:users', 'phone' => 'required|string|unique:users', 'password' => 'required|string|min:6', 'email' => 'nullable|email', 'department_id' => 'nullable|exists:departments,id', 'position_id' => 'nullable|exists:positions,id', 'gender' => 'nullable|string']);
        $data['password'] = bcrypt($data['password']);
        $data['status'] = 'active';
        $user = User::create($data);

        if ($request->filled('employee_no')) {
            $user->profile()->create(['employee_no' => $request->employee_no, 'hire_date' => $request->hire_date ?? now()]);
        }

        return response()->json(['code' => 0, 'data' => $user]);
    }

    public function departments(Request $request): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => Department::with(['children', 'manager', 'users'])->whereNull('parent_id')->orderBy('sort_order')->get()]);
    }

    public function storeDepartment(Request $request): JsonResponse
    {
        $data = $request->validate(['name' => 'required|string', 'parent_id' => 'nullable|exists:departments,id', 'manager_id' => 'nullable|exists:users,id']);
        return response()->json(['code' => 0, 'data' => Department::create($data)]);
    }

    public function positions(Request $request): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => Position::with('department')->get()]);
    }

    public function skills(Request $request): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => SkillTag::orderBy('sort_order')->get()]);
    }

    public function storeSkill(Request $request): JsonResponse
    {
        $data = $request->validate(['name' => 'required|string|unique:skill_tags', 'category' => 'nullable|string', 'color' => 'nullable|string']);
        return response()->json(['code' => 0, 'data' => SkillTag::create($data)]);
    }

    public function certificates(Request $request): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => Certificate::with('profile.user')->orderBy('expire_date')->get()]);
    }
}

class CustomerController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Customer::with(['contacts', 'assignedUser']);
        if ($request->filled('keyword')) $query->where('name', 'like', "%{$request->keyword}%");
        if ($request->filled('category')) $query->where('category', $request->category);
        if ($request->filled('industry')) $query->where('industry', 'like', "%{$request->industry}%");
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }

    public function show(Customer $customer): JsonResponse
    {
        $customer->load(['contacts', 'devices', 'projects', 'serviceOrders', 'followUps.user', 'receivables']);
        return response()->json(['code' => 0, 'data' => $customer]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate(['name' => 'required|string', 'industry' => 'nullable|string', 'category' => 'nullable|string', 'province' => 'nullable|string', 'city' => 'nullable|string', 'district' => 'nullable|string', 'address' => 'nullable|string', 'tags' => 'nullable|array', 'description' => 'nullable|string']);
        $customer = Customer::create($data);
        return response()->json(['code' => 0, 'data' => $customer]);
    }

    public function followUps(Request $request, Customer $customer): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => $customer->followUps()->with('user')->orderBy('created_at', 'desc')->paginate()]);
    }

    public function devices(Request $request, Customer $customer): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => $customer->devices()->paginate()]);
    }
}

class ExpenseController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = ExpenseClaim::with(['user', 'project', 'approver']);
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('category')) $query->where('category', $request->category);
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate(['category' => 'required|string', 'description' => 'required|string', 'project_id' => 'nullable|exists:projects,id', 'items' => 'required|array', 'items.*.item_date' => 'required|date', 'items.*.description' => 'required|string', 'items.*.amount' => 'required|numeric|min:0']);
        $data['user_id'] = $request->user()->id;
        $data['status'] = 'submitted';
        $data['total_amount'] = collect($data['items'])->sum('amount');
        $items = $data['items']; unset($data['items']);
        $claim = ExpenseClaim::create($data);
        foreach ($items as $item) { $claim->items()->create($item); }
        return response()->json(['code' => 0, 'data' => $claim->load('items')]);
    }

    public function approve(Request $request, ExpenseClaim $claim): JsonResponse
    {
        $request->validate(['action' => 'required|in:approved,rejected', 'comment' => 'nullable|string']);
        $claim->update(['status' => $request->action, 'approver_id' => $request->user()->id, 'approved_at' => now(), 'reject_reason' => $request->action === 'rejected' ? $request->comment : null]);
        return response()->json(['code' => 0, 'message' => '审批完成']);
    }

    public function myClaims(Request $request): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => $request->user()->expenseClaims()->with('items', 'project')->orderBy('created_at', 'desc')->paginate()]);
    }
}

class VehicleController extends Controller
{
    public function index(): JsonResponse { return response()->json(['code' => 0, 'data' => Vehicle::with(['department', 'responsibleUser'])->get()]); }
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate(['plate_no' => 'required|string|unique:vehicles', 'brand' => 'required|string', 'model' => 'required|string', 'department_id' => 'nullable|exists:departments,id', 'responsible_user_id' => 'nullable|exists:users,id']);
        return response()->json(['code' => 0, 'data' => Vehicle::create($data)]);
    }
    public function usageRequests(Request $request): JsonResponse { return response()->json(['code' => 0, 'data' => VehicleUsageRequest::with(['applicant', 'vehicle', 'approver'])->orderBy('usage_date', 'desc')->paginate()]); }
    public function storeUsageRequest(Request $request): JsonResponse
    {
        $data = $request->validate(['usage_date' => 'required|date', 'start_time' => 'required', 'end_time' => 'required', 'destination' => 'required|string', 'purpose' => 'required|string', 'passengers' => 'nullable|integer', 'self_drive' => 'nullable|boolean']);
        $data['applicant_id'] = $request->user()->id;
        $data['status'] = 'pending';
        return response()->json(['code' => 0, 'data' => VehicleUsageRequest::create($data)]);
    }
    public function dispatchVehicle(Request $request, VehicleUsageRequest $usageRequest): JsonResponse
    {
        $data = $request->validate(['vehicle_id' => 'required|exists:vehicles,id', 'action' => 'required|in:approved,rejected']);
        $usageRequest->update(['vehicle_id' => $data['vehicle_id'], 'status' => $data['action'], 'approver_id' => $request->user()->id, 'approved_at' => now()]);
        return response()->json(['code' => 0, 'message' => '审批完成']);
    }
}

class InventoryController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = InventoryItem::with('warehouse');
        if ($request->filled('category')) $query->where('category', $request->category);
        if ($request->filled('keyword')) $query->where('name', 'like', "%{$request->keyword}%");
        return response()->json(['code' => 0, 'data' => $query->paginate()]);
    }
    public function stockRecords(Request $request): JsonResponse
    {
        $query = StockRecord::with(['inventoryItem', 'warehouse', 'operator']);
        if ($request->filled('type')) $query->where('type', $request->type);
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate()]);
    }
    public function warehouses(): JsonResponse { return response()->json(['code' => 0, 'data' => Warehouse::all()]); }
}

class FinanceController extends Controller
{
    public function overview(Request $request): JsonResponse
    {
        $monthStart = now()->startOfMonth();
        $totalRevenue = Receivable::where('received_date', '>=', $monthStart)->sum('received_amount');
        $totalReceivable = Receivable::where('status', '!=', 'fully_paid')->sum('remaining_amount');
        $totalPayable = Payable::where('status', '!=', 'fully_paid')->sum('remaining_amount');
        return response()->json(['code' => 0, 'data' => compact('totalRevenue', 'totalReceivable', 'totalPayable')]);
    }
    public function receivables(Request $request): JsonResponse { return response()->json(['code' => 0, 'data' => Receivable::with(['customer', 'project'])->orderBy('due_date')->paginate()]); }
    public function payables(Request $request): JsonResponse { return response()->json(['code' => 0, 'data' => Payable::with(['supplier', 'project'])->orderBy('due_date')->paginate()]); }
}

class DiskController extends Controller
{
    public function folders(Request $request): JsonResponse { return response()->json(['code' => 0, 'data' => DiskFolder::withCount('files')->where('parent_id', $request->parent_id ?? null)->orderBy('name')->get()]); }
    public function files(Request $request): JsonResponse { return response()->json(['code' => 0, 'data' => DiskFile::where('folder_id', $request->folder_id)->orderBy('name')->paginate()]); }
    public function createFolder(Request $request): JsonResponse { $data = $request->validate(['name' => 'required|string', 'parent_id' => 'nullable|exists:disk_folders,id']); $data['created_by'] = $request->user()->id; return response()->json(['code' => 0, 'data' => DiskFolder::create($data)]); }
    public function upload(Request $request): JsonResponse
    {
        $request->validate(['file' => 'required|file', 'folder_id' => 'required|exists:disk_folders,id']);
        $file = $request->file('file');
        $path = $file->store('attachments/' . date('Y/m'), 'attachments');
        return response()->json(['code' => 0, 'data' => DiskFile::create(['folder_id' => $request->folder_id, 'name' => $file->hashName(), 'original_name' => $file->getClientOriginalName(), 'extension' => $file->extension(), 'mime_type' => $file->getMimeType(), 'size' => $file->getSize(), 'path' => $path, 'uploaded_by' => $request->user()->id])]);
    }
}

class KnowledgeController extends Controller
{
    public function categories(): JsonResponse { return response()->json(['code' => 0, 'data' => KnowledgeCategory::withCount('articles')->whereNull('parent_id')->with('children')->orderBy('sort_order')->get()]); }
    public function articles(Request $request): JsonResponse
    {
        $query = KnowledgeArticle::with(['category', 'author'])->where('status', 'published');
        if ($request->filled('category_id')) $query->where('category_id', $request->category_id);
        if ($request->filled('keyword')) $query->where('title', 'like', "%{$request->keyword}%");
        return response()->json(['code' => 0, 'data' => $query->orderBy('published_at', 'desc')->paginate()]);
    }
    public function show(KnowledgeArticle $article): JsonResponse
    {
        $article->increment('view_count');
        return response()->json(['code' => 0, 'data' => $article->load('category', 'author')]);
    }
}

class NotificationController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = $request->user()->notifications();
        if ($request->filled('type')) $query->where('type', $request->type);
        if ($request->boolean('unread')) $query->whereNull('read_at');
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate()]);
    }

    public function markAsRead(Request $request): JsonResponse
    {
        $request->validate(['notification_id' => 'required']);
        $notification = $request->user()->allNotifications()->where('id', $request->notification_id)->first();
        $notification?->update(['read_at' => now()]);
        return response()->json(['code' => 0, 'message' => '已标记为已读']);
    }

    public function markAllAsRead(Request $request): JsonResponse
    {
        $request->user()->notifications()->update(['read_at' => now()]);
        return response()->json(['code' => 0, 'message' => '全部已读']);
    }

    public function unreadCount(): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => ['count' => $request->user()->notifications()->count()]]);
    }
}

class DashboardController extends Controller
{
    public function stats(): JsonResponse
    {
        $today = today();
        $pendingTodos = 20; // placeholder: 实际从审批+工单统计
        $activeProjects = Project::where('status', 'in_progress')->count();
        $pendingServiceOrders = ServiceOrder::whereIn('status', ['pending', 'assigned'])->count();
        $monthlyRevenue = Receivable::whereMonth('received_date', $month = now()->month)->whereYear('received_date', now()->year)->sum('received_amount');
        $todayAttendance = AttendanceRecord::where('date', $today)->count();
        $leaveRequests = \App\Models\LeaveRequest::where('status', 'pending')->count();
        $expensePending = ExpenseClaim::where('status', 'submitted')->count();

        return response()->json(['code' => 0, 'data' => compact('pendingTodos', 'activeProjects', 'pendingServiceOrders', 'monthlyRevenue', 'todayAttendance', 'leaveRequests', 'expensePending')]);
    }

    public function recentProjects(): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => Project::with(['customer', 'manager'])->where('status', 'in_progress')->orderBy('updated_at', 'desc')->take(10)->get()]);
    }

    public function recentServiceOrders(): JsonResponse
    {
        return response()->json(['code' => 0, 'data' => ServiceOrder::with(['customer', 'assignedUser'])->whereIn('status', ['pending', 'assigned', 'in_progress'])->orderBy('created_at', 'desc')->take(10)->get()]);
    }
}

class SystemLogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = \Illuminate\Support\Facades\DB::table('system_logs');
        if ($request->filled('type')) $query->where('type', $request->type);
        if ($request->filled('module')) $query->where('module', $request->module);
        if ($request->filled('user_id')) $query->where('user_id', $request->user_id);
        if ($request->filled('start_date')) $query->where('created_at', '>=', $request->start_date);
        if ($request->filled('end_date')) $query->where('created_at', '<=', $request->end_date . ' 23:59:59');
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 20)]);
    }
}
