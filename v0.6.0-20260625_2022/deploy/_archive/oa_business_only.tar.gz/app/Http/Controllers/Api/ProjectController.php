<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{Project, ProjectContract, ProjectMember, ConstructionLog, ProjectMaterial, ProjectSettlement, PurchaseOrder, Supplier};
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Project::with(['customer', 'manager', 'members']);
        if ($request->filled('keyword')) $query->where('name', 'like', "%{$request->keyword}%");
        if ($request->filled('stage')) $query->where('stage', $request->stage);
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('customer_id')) $query->where('customer_id', $request->customer_id);
        if ($request->filled('type')) $query->where('type', $request->type);

        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }

    public function show(Project $project): JsonResponse
    {
        $project->load(['customer', 'manager', 'members.user', 'contract.paymentNodes', 'purchaseOrders.items', 'constructionLogs.user', 'materials', 'settlement', 'devices']);
        return response()->json(['code' => 0, 'data' => $project]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:200', 'customer_id' => 'required|exists:customers,id',
            'type' => 'required|string', 'description' => 'nullable|string',
            'budget_device' => 'nullable|numeric|min:0', 'budget_material' => 'nullable|numeric|min:0',
            'budget_labor' => 'nullable|numeric|min:0', 'budget_outsource' => 'nullable|numeric|min:0',
            'budget_other' => 'nullable|numeric|min:0', 'manager_id' => 'required|exists:users,id',
            'start_date' => 'nullable|date', 'end_date' => 'nullable|date', 'priority' => 'nullable|string',
            'member_ids' => 'nullable|array', 'member_ids.*' => 'exists:users,id',
        ]);

        $memberIds = $data['member_ids'] ?? [];
        unset($data['member_ids']);

        $project = Project::create($data + ['stage' => 'initiation', 'status' => 'pending', 'progress' => 0]);

        // 添加团队成员
        foreach ($memberIds as $userId) {
            ProjectMember::create(['project_id' => $project->id, 'user_id' => $userId, 'role' => 'worker', 'status' => 'active']);
        }
        if (!in_array($data['manager_id'], $memberIds)) {
            ProjectMember::create(['project_id' => $project->id, 'user_id' => $data['manager_id'], 'role' => 'manager', 'status' => 'active']);
        }

        return response()->json(['code' => 0, 'message' => '创建成功', 'data' => $project->load('customer', 'manager')]);
    }

    public function update(Request $request, Project $project): JsonResponse
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:200', 'stage' => 'sometimes|string',
            'status' => 'sometimes|string', 'progress' => 'sometimes|integer|min:0|max:100',
            'description' => 'nullable|string', 'end_date' => 'nullable|date', 'priority' => 'nullable|string',
        ]);

        $project->update($data);
        return response()->json(['code' => 0, 'message' => '更新成功', 'data' => $project]);
    }

    public function updateStage(Request $request, Project $project): JsonResponse
    {
        $request->validate(['stage' => 'required|string']);
        $project->update(['stage' => $request->stage]);
        return response()->json(['code' => 0, 'message' => '阶段更新成功']);
    }

    public function constructionLogs(Request $request, Project $project): JsonResponse
    {
        $logs = $project->constructionLogs()->with('user')->orderBy('work_date', 'desc')->paginate($request->per_page ?? 15);
        return response()->json(['code' => 0, 'data' => $logs]);
    }

    public function storeConstructionLog(Request $request, Project $project): JsonResponse
    {
        $data = $request->validate([
            'work_date' => 'required|date', 'content' => 'required|string',
            'weather' => 'nullable|string', 'problems' => 'nullable|string',
            'solutions' => 'nullable|string', 'photos' => 'nullable|array',
            'work_hours' => 'nullable|numeric', 'location' => 'nullable|string',
        ]);
        $data['project_id'] = $project->id;
        $data['user_id'] = $request->user()->id;
        $log = ConstructionLog::create($data);
        return response()->json(['code' => 0, 'data' => $log]);
    }

    // 供应商
    public function suppliers(Request $request): JsonResponse
    {
        $query = Supplier::query();
        if ($request->filled('keyword')) $query->where('name', 'like', "%{$request->keyword}%");
        if ($request->filled('category')) $query->where('category', $request->category);
        return response()->json(['code' => 0, 'data' => $query->paginate($request->per_page ?? 15)]);
    }

    public function storeSupplier(Request $request): JsonResponse
    {
        $data = $request->validate(['name' => 'required|string', 'contact_person' => 'required|string', 'phone' => 'required|string', 'email' => 'nullable|email', 'address' => 'nullable|string', 'category' => 'nullable|string']);
        return response()->json(['code' => 0, 'data' => Supplier::create($data)]);
    }
}
