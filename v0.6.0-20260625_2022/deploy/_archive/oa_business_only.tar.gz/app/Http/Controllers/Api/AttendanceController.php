<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AttendanceRecord;
use App\Models\LeaveRequest;
use App\Models\OvertimeRequest;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AttendanceController extends Controller
{
    public function overview(Request $request): JsonResponse
    {
        $today = today()->format('Y-m-d');
        $totalUsers = User::where('status', 'active')->count();
        $present = AttendanceRecord::where('date', $today)->where('status', 'normal')->count();
        $late = AttendanceRecord::where('date', $today)->where('status', 'late')->count();
        $absent = AttendanceRecord::where('date', $today)->where('status', 'absent')->count();
        $fieldWork = AttendanceRecord::where('date', $today)->where('status', 'field_work')->count();

        return response()->json(['code' => 0, 'data' => compact('totalUsers', 'present', 'late', 'absent', 'fieldWork')]);
    }

    public function clockIn(Request $request): JsonResponse
    {
        $request->validate([
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'location' => 'nullable|string|max:200',
            'project_id' => 'nullable|exists:projects,id',
            'remark' => 'nullable|string',
        ]);

        $today = today()->format('Y-m-d');
        $record = AttendanceRecord::firstOrCreate(['user_id' => Auth::id(), 'date' => $today]);
        $record->update([
            'clock_in' => now()->format('H:i:s'),
            'clock_in_location' => $request->location,
            'clock_in_lat' => $request->latitude,
            'clock_in_lng' => $request->longitude,
            'project_id' => $request->project_id,
            'remark' => $request->remark,
        ]);

        return response()->json(['code' => 0, 'message' => '签到成功', 'data' => $record]);
    }

    public function clockOut(Request $request): JsonResponse
    {
        $request->validate(['latitude' => 'nullable|numeric', 'longitude' => 'nullable|numeric', 'location' => 'nullable|string|max:200']);

        $today = today()->format('Y-m-d');
        $record = AttendanceRecord::where('user_id', Auth::id())->where('date', $today)->firstOrFail();
        $record->update([
            'clock_out' => now()->format('H:i:s'),
            'clock_out_location' => $request->location,
            'clock_out_lat' => $request->latitude,
            'clock_out_lng' => $request->longitude,
        ]);

        // 计算工时
        if ($record->clock_in && $record->clock_out) {
            $start = \Carbon\Carbon::parse($today . ' ' . $record->clock_in);
            $end = \Carbon\Carbon::parse($today . ' ' . $record->clock_out);
            $record->work_hours = $start->diffInMinutes($end) / 60;
            $record->save();
        }

        return response()->json(['code' => 0, 'message' => '签退成功', 'data' => $record]);
    }

    public function records(Request $request): JsonResponse
    {
        $query = AttendanceRecord::with(['user', 'project']);
        if ($request->filled('user_id')) $query->where('user_id', $request->user_id);
        if ($request->filled('start_date')) $query->where('date', '>=', $request->start_date);
        if ($request->filled('end_date')) $query->where('date', '<=', $request->end_date);
        if ($request->filled('status')) $query->where('status', $request->status);

        $records = $query->orderBy('date', 'desc')->paginate($request->per_page ?? 15);
        return response()->json(['code' => 0, 'data' => $records]);
    }

    public function leaveRequests(Request $request): JsonResponse
    {
        $query = LeaveRequest::with(['user', 'approver']);
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('type')) $query->where('type', $request->type);

        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }

    public function storeLeaveRequest(Request $request): JsonResponse
    {
        $data = $request->validate([
            'type' => 'required|string', 'start_date' => 'required|date', 'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'required|string', 'days' => 'required|numeric|min:0.5',
        ]);
        $data['user_id'] = Auth::id();
        $data['status'] = 'pending';

        $leave = LeaveRequest::create($data);
        return response()->json(['code' => 0, 'message' => '申请成功', 'data' => $leave]);
    }

    public function approveLeave(Request $request, LeaveRequest $leave): JsonResponse
    {
        $request->validate(['action' => 'required|in:approved,rejected', 'comment' => 'nullable|string']);

        $leave->update([
            'status' => $request->action, 'approver_id' => Auth::id(),
            'approved_at' => now(), 'reject_reason' => $request->action === 'rejected' ? $request->comment : null,
        ]);

        return response()->json(['code' => 0, 'message' => $request->action === 'approved' ? '已批准' : '已驳回']);
    }

    public function overtimeRequests(Request $request): JsonResponse
    {
        $query = OvertimeRequest::with(['user', 'approver']);
        return response()->json(['code' => 0, 'data' => $query->orderBy('created_at', 'desc')->paginate($request->per_page ?? 15)]);
    }

    public function report(Request $request): JsonResponse
    {
        $request->validate(['month' => 'required|date_format:Y-m']);
        $month = $request->month;
        $users = User::where('status', 'active')->with(['attendanceRecords' => function ($q) use ($month) {
            $q->where('date', 'like', "$month%");
        }])->get();

        $data = $users->map(fn($u) => [
            'user' => $u, 'total_days' => $u->attendanceRecords->count(),
            'late_count' => $u->attendanceRecords->where('status', 'late')->count(),
            'absent_count' => $u->attendanceRecords->where('status', 'absent')->count(),
            'overtime_hours' => $u->attendanceRecords->sum('overtime_hours'),
        ]);

        return response()->json(['code' => 0, 'data' => $data]);
    }
}
