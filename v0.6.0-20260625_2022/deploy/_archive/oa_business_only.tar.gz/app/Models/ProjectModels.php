<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Project extends Model
{
    use HasFactory;

    protected $fillable = [
        'project_no', 'name', 'customer_id', 'type', 'stage', 'status', 'description',
        'budget_device', 'budget_material', 'budget_labor', 'budget_outsource', 'budget_other',
        'progress', 'manager_id', 'start_date', 'end_date', 'actual_end_date', 'priority',
    ];

    protected $casts = [
        'budget_device' => 'decimal:2', 'budget_material' => 'decimal:2',
        'budget_labor' => 'decimal:2', 'budget_outsource' => 'decimal:2', 'budget_other' => 'decimal:2',
        'start_date' => 'date', 'end_date' => 'date', 'actual_end_date' => 'date',
        'stage' => \App\Enums\ProjectStage::class, 'status' => 'string',
    ];

    protected static function booted()
    {
        static::creating(function ($project) {
            if (empty($project->project_no)) {
                $count = Project::whereDate('created_at', today())->count() + 1;
                $project->project_no = 'PRJ-' . date('Ymd') . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);
            }
        });
    }

    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function manager(): BelongsTo { return $this->belongsTo(User::class, 'manager_id'); }
    public function members(): BelongsToMany { return $this->belongsToMany(User::class, 'project_members')->withPivot('role', 'status')->withTimestamps(); }
    public function contract(): HasMany { return $this->hasMany(ProjectContract::class); }
    public function purchaseOrders(): HasMany { return $this->hasMany(PurchaseOrder::class); }
    public function constructionLogs(): HasMany { return $this->hasMany(ConstructionLog::class); }
    public function materials(): HasMany { return $this->hasMany(ProjectMaterial::class); }
    public function settlement(): HasMany { return $this->hasMany(ProjectSettlement::class); }
    public function serviceOrders(): HasMany { return $this->hasMany(ServiceOrder::class); }
    public function devices(): HasMany { return $this->hasMany(CustomerDevice::class); }

    public function getTotalBudgetAttribute(): float
    {
        return $this->budget_device + $this->budget_material + $this->budget_labor + $this->budget_outsource + $this->budget_other;
    }
}

class ProjectContract extends Model
{
    use HasFactory;

    protected $fillable = ['project_id', 'contract_no', 'contract_amount', 'payment_method', 'contract_start', 'contract_end', 'status', 'attachment', 'signed_at', 'notes'];

    protected $casts = ['contract_amount' => 'decimal:2', 'contract_start' => 'date', 'contract_end' => 'date', 'signed_at' => 'datetime'];

    public function project(): BelongsTo { return $this->belongsTo(Project::class); }
    public function paymentNodes(): HasMany { return $this->hasMany(ContractPaymentNode::class); }
}

class ContractPaymentNode extends Model
{
    use HasFactory;

    protected $fillable = ['contract_id', 'name', 'percentage', 'amount', 'planned_date', 'actual_date', 'status', 'paid_amount', 'notes'];

    protected $casts = ['percentage' => 'decimal:2', 'amount' => 'decimal:2', 'paid_amount' => 'decimal:2', 'planned_date' => 'date', 'actual_date' => 'date'];

    public function contract(): BelongsTo { return $this->belongsTo(ProjectContract::class); }
}

class Supplier extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'contact_person', 'phone', 'email', 'address', 'category', 'rating', 'status', 'notes'];

    protected $casts = ['rating' => 'integer'];
}

class PurchaseOrder extends Model
{
    use HasFactory;

    protected $fillable = ['project_id', 'supplier_id', 'po_no', 'total_amount', 'status', 'approved_by', 'approved_at', 'notes'];

    protected $casts = ['total_amount' => 'decimal:2', 'approved_at' => 'datetime'];

    public function project(): BelongsTo { return $this->belongsTo(Project::class); }
    public function supplier(): BelongsTo { return $this->belongsTo(Supplier::class); }
    public function items(): HasMany { return $this->hasMany(PurchaseItem::class); }

    protected static function booted()
    {
        static::creating(function ($po) {
            if (empty($po->po_no)) {
                $count = PurchaseOrder::whereDate('created_at', today())->count() + 1;
                $po->po_no = 'PO-' . date('Ymd') . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);
            }
        });
    }
}

class PurchaseItem extends Model
{
    use HasFactory;

    protected $fillable = ['purchase_order_id', 'item_name', 'specification', 'quantity', 'unit', 'unit_price', 'total_price', 'received_quantity', 'notes'];

    protected $casts = ['quantity' => 'decimal:2', 'unit_price' => 'decimal:2', 'total_price' => 'decimal:2', 'received_quantity' => 'decimal:2'];

    public function purchaseOrder(): BelongsTo { return $this->belongsTo(PurchaseOrder::class); }
}

class ConstructionLog extends Model
{
    use HasFactory;

    protected $fillable = ['project_id', 'user_id', 'work_date', 'weather', 'content', 'problems', 'solutions', 'photos', 'work_hours', 'location', 'status'];

    protected $casts = ['photos' => 'array', 'work_date' => 'date', 'work_hours' => 'decimal:1'];

    public function project(): BelongsTo { return $this->belongsTo(Project::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}

class ProjectMaterial extends Model
{
    use HasFactory;

    protected $fillable = ['project_id', 'material_name', 'specification', 'quantity', 'unit', 'unit_cost', 'total_cost', 'used_by', 'use_date', 'inventory_item_id', 'notes'];

    protected $casts = ['quantity' => 'decimal:2', 'unit_cost' => 'decimal:2', 'total_cost' => 'decimal:2', 'use_date' => 'date'];

    public function project(): BelongsTo { return $this->belongsTo(Project::class); }
    public function usedByUser(): BelongsTo { return $this->belongsTo(User::class, 'used_by'); }
}

class ProjectSettlement extends Model
{
    use HasFactory;

    protected $fillable = ['project_id', 'total_income', 'total_cost', 'cost_labor', 'cost_material', 'cost_outsource', 'cost_other', 'profit', 'profit_rate', 'settlement_date', 'status', 'notes'];

    protected $casts = ['total_income' => 'decimal:2', 'total_cost' => 'decimal:2', 'cost_labor' => 'decimal:2', 'cost_material' => 'decimal:2', 'cost_outsource' => 'decimal:2', 'cost_other' => 'decimal:2', 'profit' => 'decimal:2', 'profit_rate' => 'decimal:2', 'settlement_date' => 'date'];

    public function project(): BelongsTo { return $this->belongsTo(Project::class); }
}
