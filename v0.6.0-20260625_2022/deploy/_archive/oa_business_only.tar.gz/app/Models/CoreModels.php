<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Department extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'parent_id', 'manager_id', 'sort_order', 'status', 'description'];

    protected $casts = ['status' => 'string'];

    public function parent(): BelongsTo { return $this->belongsTo(Department::class, 'parent_id'); }
    public function children(): HasMany { return $this->hasMany(Department::class, 'parent_id'); }
    public function manager(): BelongsTo { return $this->belongsTo(User::class, 'manager_id'); }
    public function positions(): HasMany { return $this->hasMany(Position::class); }
    public function users(): HasMany { return $this->hasMany(User::class); }
}

class Position extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'department_id', 'level', 'description', 'status', 'sort_order'];

    public function department(): BelongsTo { return $this->belongsTo(Department::class); }
    public function users(): HasMany { return $this->hasMany(User::class); }
}

class EmployeeProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'employee_no', 'hire_date', 'leave_date',
        'contract_type', 'contract_start', 'contract_end',
        'base_salary', 'salary_allowance', 'emergency_contact', 'emergency_phone',
        'bank_name', 'bank_account', 'notes',
    ];

    protected $casts = [
        'hire_date' => 'date', 'leave_date' => 'date',
        'contract_start' => 'date', 'contract_end' => 'date',
        'base_salary' => 'decimal:2', 'salary_allowance' => 'decimal:2',
    ];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function certificates(): HasMany { return $this->hasMany(Certificate::class); }
}

class SkillTag extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'category', 'color', 'description', 'sort_order'];

    public function employees(): BelongsToMany
    {
        return $this->belongsToMany(EmployeeProfile::class, 'employee_skills')
            ->withPivot('proficiency')
            ->withTimestamps();
    }
}

class Certificate extends Model
{
    use HasFactory;

    protected $fillable = [
        'employee_profile_id', 'certificate_name', 'certificate_no',
        'issue_date', 'expire_date', 'issuer', 'status', 'attachment', 'remind_days',
    ];

    protected $casts = [
        'issue_date' => 'date', 'expire_date' => 'date',
    ];

    public function profile(): BelongsTo { return $this->belongsTo(EmployeeProfile::class); }

    public function isExpiringSoon(int $days = 30): bool
    {
        return $this->expire_date && $this->expire_date->diffInDays(now()) <= $days;
    }
}

class Customer extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'credit_code', 'industry', 'category',
        'province', 'city', 'district', 'address',
        'longitude', 'latitude', 'tags', 'source', 'status',
        'assigned_user_id', 'description',
    ];

    protected $casts = ['tags' => 'array', 'longitude' => 'decimal:7', 'latitude' => 'decimal:7'];

    public function contacts(): HasMany { return $this->hasMany(CustomerContact::class); }
    public function primaryContact() { return $this->hasOne(CustomerContact::class)->where('is_primary', true); }
    public function devices(): HasMany { return $this->hasMany(CustomerDevice::class); }
    public function followUps(): HasMany { return $this->hasMany(FollowUpRecord::class); }
    public function projects(): HasMany { return $this->hasMany(Project::class); }
    public function serviceOrders(): HasMany { return $this->hasMany(ServiceOrder::class); }
    public function receivables(): HasMany { return $this->hasMany(Receivable::class); }
    public function maintenanceContracts(): HasMany { return $this->hasMany(MaintenanceContract::class); }
    public function assignedUser(): BelongsTo { return $this->belongsTo(User::class, 'assigned_user_id'); }
}

class CustomerContact extends Model
{
    use HasFactory;

    protected $fillable = ['customer_id', 'name', 'position', 'phone', 'email', 'is_primary', 'wechat', 'notes'];

    protected $casts = ['is_primary' => 'boolean'];

    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
}

class FollowUpRecord extends Model
{
    use HasFactory;

    protected $fillable = ['customer_id', 'user_id', 'type', 'content', 'next_follow_up_date', 'next_follow_up_note', 'attachments'];

    protected $casts = ['attachments' => 'array', 'next_follow_up_date' => 'date'];

    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}

class CustomerDevice extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id', 'project_id', 'device_name', 'device_type', 'brand', 'model',
        'serial_number', 'install_location', 'install_date', 'warranty_end', 'status', 'notes',
    ];

    protected $casts = ['install_date' => 'date', 'warranty_end' => 'date'];

    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function project(): BelongsTo { return $this->belongsTo(Project::class); }
}
