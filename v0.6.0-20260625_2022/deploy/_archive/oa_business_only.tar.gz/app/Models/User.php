<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles, SoftDeletes;

    protected $fillable = [
        'name', 'username', 'email', 'phone', 'password', 'avatar',
        'department_id', 'position_id', 'gender', 'id_card', 'status',
        'last_login_at', 'last_login_ip',
    ];

    protected $hidden = ['password', 'remember_token', 'deleted_at'];
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'last_login_at' => 'datetime',
        'status' => \App\Enums\UserStatus::class,
        'gender' => \App\Enums\Gender::class,
    ];

    // ========== 关联关系 ==========

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function position()
    {
        return $this->belongsTo(Position::class);
    }

    public function profile()
    {
        return $this->hasOne(EmployeeProfile::class);
    }

    public function skills()
    {
        return $this->belongsToMany(SkillTag::class, 'employee_skills')
            ->withPivot('proficiency')
            ->withTimestamps();
    }

    public function certificates()
    {
        return $this->hasManyThrough(Certificate::class, EmployeeProfile::class);
    }

    public function attendanceRecords()
    {
        return $this->hasMany(AttendanceRecord::class);
    }

    public function managedProjects()
    {
        return $this->hasMany(Project::class, 'manager_id');
    }

    public function projectMemberships()
    {
        return $this->hasMany(ProjectMember::class);
    }

    public function expenseClaims()
    {
        return $this->hasMany(ExpenseClaim::class);
    }

    public function serviceOrdersAssigned()
    {
        return $this->hasMany(ServiceOrder::class, 'assigned_to');
    }

    public function vehicleUsageRequests()
    {
        return $this->hasMany(VehicleUsageRequest::class, 'applicant_id');
    }

    public function notifications()
    {
        return $this->morphMany(Notification::class, 'notifiable')
            ->whereNull('read_at')
            ->orderBy('created_at', 'desc');
    }

    public function allNotifications()
    {
        return $this->morphMany(Notification::class, 'notifiable')
            ->orderBy('created_at', 'desc');
    }

    // ========== 辅助方法 ==========

    public function hasSkill(string $skillName): bool
    {
        return $this->skills()->where('name', $skillName)->exists();
    }

    public function isActive(): bool
    {
        return $this->status === \App\Enums\UserStatus::ACTIVE;
    }

    public function getInitialsAttribute(): string
    {
        return mb_substr($this->name, 0, 1);
    }
}
