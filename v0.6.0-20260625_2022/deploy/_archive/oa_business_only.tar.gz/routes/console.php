<?php

use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| Console Routes
|--------------------------------------------------------------------------
*/

Artisan::command('oa:seed-admin', function () {
    $admin = \App\Models\User::firstOrCreate(
        ['username' => 'admin'],
        ['name' => '张建国', 'email' => 'admin@security-oa.com', 'phone' => '13800138000', 'password' => bcrypt('admin123'), 'status' => 'active']
    );
    $admin->assignRole('admin');

    $manager = \App\Models\User::firstOrCreate(
        ['username' => 'manager'],
        ['name' => '李明辉', 'email' => 'manager@security-oa.com', 'phone' => '13900139001', 'password' => bcrypt('123456'), 'status' => 'active']
    );
    $manager->assignRole('manager');

    $user = \App\Models\User::firstOrCreate(
        ['username' => 'user'],
        ['name' => '王小红', 'email' => 'user@security-oa.com', 'phone' => '13700137002', 'password' => bcrypt('123456'), 'status' => 'active']
    );
    $user->assignRole('user');

    $this->info('默认管理员已创建: admin / admin123');
})->purpose('创建默认管理员账号');

Artisan::command('oa:seed-demo', function () {
    $this->call('oa:seed-admin');

    // 创建部门
    $techDept = \App\Models\Department::firstOrCreate(['name' => '技术部'], ['sort_order' => 1]);
    $salesDept = \App\Models\Department::firstOrCreate(['name' => '销售部'], ['sort_order' => 2]);
    $serviceDept = \App\Models\Department::firstOrCreate(['name' => '售后部'], ['sort_order' => 3]);
    $financeDept = \App\Models\Department::firstOrCreate(['name' => '财务部'], ['sort_order' => 4]);

    // 创建技能标签
    $skills = ['监控安装', '门禁调试', '网络配置', '报警系统', '云平台部署', '弱电施工', '综合布线', 'CAD设计'];
    foreach ($skills as $skill) {
        \App\Models\SkillTag::firstOrCreate(['name' => $skill]);
    }

    // 创建示例客户
    $customers = ['阳光小学', '中心医院', '科技园区A区', '万达工厂', '龙城商场'];
    foreach ($customers as $name) {
        \App\Models\Customer::firstOrCreate(['name' => $name], [
            'category' => 'normal', 'province' => '广东', 'city' => '深圳', 'district' => '南山区',
            'address' => '南山区科技路' . rand(1, 100) . '号', 'status' => 'active',
        ]);
    }

    $this->info('演示数据已创建');
})->purpose('创建演示数据');
