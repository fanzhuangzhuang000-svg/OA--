<?php

use App\Http\Controllers\Api\{
    AuthController, DashboardController,
    AttendanceController, EmployeeController, CustomerController,
    ProjectController, ServiceController, ExpenseController,
    VehicleController, InventoryController, FinanceController,
    DiskController, KnowledgeController, NotificationController,
    SystemLogController
};
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes - 安防运维OA系统
|--------------------------------------------------------------------------
*/

// 公开路由（无需认证）
Route::prefix('auth')->group(function () {
    Route::post('login', [AuthController::class, 'login']);
});

// 需要认证的路由
Route::middleware('auth:sanctum')->group(function () {

    // 认证相关
    Route::post('auth/logout', [AuthController::class, 'logout']);
    Route::get('auth/userinfo', [AuthController::class, 'userInfo']);

    // 工作台
    Route::prefix('dashboard')->group(function () {
        Route::get('stats', [DashboardController::class, 'stats']);
        Route::get('recent-projects', [DashboardController::class, 'recentProjects']);
        Route::get('recent-service-orders', [DashboardController::class, 'recentServiceOrders']);
    });

    // 考勤管理
    Route::prefix('attendance')->group(function () {
        Route::get('overview', [AttendanceController::class, 'overview']);
        Route::post('clock-in', [AttendanceController::class, 'clockIn']);
        Route::post('clock-out', [AttendanceController::class, 'clockOut']);
        Route::get('records', [AttendanceController::class, 'records']);
        Route::get('report', [AttendanceController::class, 'report']);
        Route::get('leave', [AttendanceController::class, 'leaveRequests']);
        Route::post('leave', [AttendanceController::class, 'storeLeaveRequest']);
        Route::post('leave/{leave}/approve', [AttendanceController::class, 'approveLeave']);
        Route::get('overtime', [AttendanceController::class, 'overtimeRequests']);
    });

    // 员工管理
    Route::prefix('employees')->group(function () {
        Route::get('/', [EmployeeController::class, 'index']);
        Route::post('/', [EmployeeController::class, 'store']);
        Route::get('departments', [EmployeeController::class, 'departments']);
        Route::post('departments', [EmployeeController::class, 'storeDepartment']);
        Route::get('positions', [EmployeeController::class, 'positions']);
        Route::get('skills', [EmployeeController::class, 'skills']);
        Route::post('skills', [EmployeeController::class, 'storeSkill']);
        Route::get('certificates', [EmployeeController::class, 'certificates']);
    });

    // 客户管理
    Route::prefix('customers')->group(function () {
        Route::get('/', [CustomerController::class, 'index']);
        Route::post('/', [CustomerController::class, 'store']);
        Route::get('{customer}', [CustomerController::class, 'show']);
        Route::get('{customer}/follow-ups', [CustomerController::class, 'followUps']);
        Route::get('{customer}/devices', [CustomerController::class, 'devices']);
    });

    // 项目管理
    Route::prefix('projects')->group(function () {
        Route::get('/', [ProjectController::class, 'index']);
        Route::post('/', [ProjectController::class, 'store']);
        Route::get('{project}', [ProjectController::class, 'show']);
        Route::put('{project}', [ProjectController::class, 'update']);
        Route::put('{project}/stage', [ProjectController::class, 'updateStage']);
        Route::get('{project}/construction-logs', [ProjectController::class, 'constructionLogs']);
        Route::post('{project}/construction-logs', [ProjectController::class, 'storeConstructionLog']);
        Route::get('suppliers', [ProjectController::class, 'suppliers']);
        Route::post('suppliers', [ProjectController::class, 'storeSupplier']);
    });

    // 售后服务
    Route::prefix('service')->group(function () {
        Route::get('orders', [ServiceController::class, 'index']);
        Route::post('orders', [ServiceController::class, 'store']);
        Route::get('orders/{serviceOrder}', [ServiceController::class, 'show']);
        Route::post('orders/{serviceOrder}/assign', [ServiceController::class, 'assign']);
        Route::post('orders/{serviceOrder}/start', [ServiceController::class, 'startRepair']);
        Route::post('orders/{serviceOrder}/complete', [ServiceController::class, 'completeRepair']);
        Route::post('orders/{serviceOrder}/confirm', [ServiceController::class, 'confirmByCustomer']);
        Route::get('stats', [ServiceController::class, 'stats']);
        Route::get('maintenance-contracts', [ServiceController::class, 'maintenanceContracts']);
    });

    // 报销管理
    Route::prefix('expenses')->group(function () {
        Route::get('/', [ExpenseController::class, 'index']);
        Route::post('/', [ExpenseController::class, 'store']);
        Route::post('{claim}/approve', [ExpenseController::class, 'approve']);
        Route::get('my', [ExpenseController::class, 'myClaims']);
    });

    // 车辆管理
    Route::prefix('vehicles')->group(function () {
        Route::get('/', [VehicleController::class, 'index']);
        Route::post('/', [VehicleController::class, 'store']);
        Route::get('usage', [VehicleController::class, 'usageRequests']);
        Route::post('usage', [VehicleController::class, 'storeUsageRequest']);
        Route::post('usage/{usageRequest}/dispatch', [VehicleController::class, 'dispatchVehicle']);
    });

    // 库存管理
    Route::prefix('inventory')->group(function () {
        Route::get('/', [InventoryController::class, 'index']);
        Route::get('stock-records', [InventoryController::class, 'stockRecords']);
        Route::get('warehouses', [InventoryController::class, 'warehouses']);
    });

    // 财务管理
    Route::prefix('finance')->group(function () {
        Route::get('overview', [FinanceController::class, 'overview']);
        Route::get('receivables', [FinanceController::class, 'receivables']);
        Route::get('payables', [FinanceController::class, 'payables']);
    });

    // 公司网盘
    Route::prefix('disk')->group(function () {
        Route::get('folders', [DiskController::class, 'folders']);
        Route::post('folders', [DiskController::class, 'createFolder']);
        Route::get('files', [DiskController::class, 'files']);
        Route::post('upload', [DiskController::class, 'upload']);
    });

    // 知识库
    Route::prefix('knowledge')->group(function () {
        Route::get('categories', [KnowledgeController::class, 'categories']);
        Route::get('articles', [KnowledgeController::class, 'articles']);
        Route::get('articles/{article}', [KnowledgeController::class, 'show']);
    });

    // 消息中心
    Route::prefix('notifications')->group(function () {
        Route::get('/', [NotificationController::class, 'index']);
        Route::get('unread-count', [NotificationController::class, 'unreadCount']);
        Route::post('mark-read', [NotificationController::class, 'markAsRead']);
        Route::post('mark-all-read', [NotificationController::class, 'markAllAsRead']);
    });

    // 系统日志
    Route::get('system-logs', [SystemLogController::class, 'index']);
});
